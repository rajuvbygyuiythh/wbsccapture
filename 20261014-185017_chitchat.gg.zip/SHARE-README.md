# Capture session — what to share

Share this whole session folder (it is redacted by default). Start with:

1. `manifest.json` — index, counts and coverage.
2. `messages/labeled-*.jsonl` — examples you confirmed with Ctrl+Alt+I / Ctrl+Alt+O.
3. `messages/correlation.json` — which network event produced which visible message.
4. `api-catalog.json` + `websockets/*.jsonl` — endpoint and socket schemas.

Do NOT share a session captured with rawMode=true: it can contain live tokens/cookies.
Stop reason: browser-closed
