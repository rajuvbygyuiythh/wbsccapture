# Capture summary — ki ki dhora poreche, ki kora jabe

Session: C:\Users\papi\Downloads\root-project-capture-fix-UNVERIFIED\root-project\capture\capture-sessions\20261014-185017_chitchat.gg
Site: https://chitchat.gg/

## Capability checklist

[HOYE GECHE] Browser page + DOM capture
             => labh: Page-er DOM pore sekhane click/type kore chalano jabe
[HOYE GECHE] HTTP / API traffic capture
             => labh: Site kon API diye ki kore, seta bujha jabe
[HOYE GECHE] WebSocket live frames (realtime chat-er vitti) (socket 10 ta, frame pathano 60, esheche 90)
             => labh: Socket diye sorasori realtime chat korar poth paoya jabe
[BAKI]       Incoming message method CONFIRMED (apnar marker) (incoming candidate 92 ta dhora poreche)
             => korte hobe: Onner message asha matro Ctrl+Alt+I chapen
[BAKI]       Outgoing message method CONFIRMED (apnar marker) (outgoing candidate 0 ta dhora poreche)
             => korte hobe: Nije message pathiyei Ctrl+Alt+O chapen
[BAKI]       DOM message fallback (DOM-e 0 ta message node dhora poreche)
             => korte hobe: Chat-e message elei auto dhora pore
[HOYE GECHE] Login session (cookies/storage) snapshot
             => labh: Login kivabe dhore rakhe, session gothon bujha jabe

## Numbers

- HTTP request/response: 1967/1931
- WebSocket: 10 socket, frame pathano 60, esheche 90
- DOM messages: 0, snapshots: 13
- Markers: incoming 0, outgoing 0

## Bot banate ja lagbe

- WebSocket frames ache: `websockets/catalog.json` + `messages/correlation.json` dekhe realtime chat-er method ber kora jabe.
- Incoming confirm hoyni: porer bar onner message ele Ctrl+Alt+I chapen.
- Outgoing confirm hoyni: porer bar nije message pathiye Ctrl+Alt+O chapen.
